# Cloudflare로 실시간 AI 변환 켜기 (무료, API 키 없음)

GitHub에 있는 사이트를 Cloudflare가 가져가서 **화면 + AI 서버**를 한 주소로 올립니다.
OpenAI 키도, 카드 등록도 필요 없습니다. Cloudflare 무료 사용량(하루 10,000 뉴런)으로
사진 변환을 하루 약 60~70장 할 수 있습니다(추정치). 사용량은 매일 오전 9시(한국 시간)에 다시 채워집니다.
무료 플랜에서는 사용량을 넘겨도 요금이 나가지 않고, "오늘 무료 사용량을 다 썼습니다"라는 안내만 뜹니다.

## 1. GitHub에 파일 올리기 (저장소 맨 위)
https://github.com/ijinsol61/remodel-simulator/upload/main 에 아래 파일을 끌어다 놓고 Commit 합니다.

| 파일 | 설명 |
|---|---|
| index.html | 화면 (Cloudflare 연결 감지 + 평면도 첨부 추가) |
| prompts.js | 지시문 (Cloudflare용 짧은 지시문 추가) |
| wrangler.jsonc | Cloudflare 설정 (AI 연결) |
| .assetsignore | 서버 파일을 화면 쪽에 공개하지 않게 하는 목록 (안 보이면 생략 가능) |
| cloudflare 폴더 (worker.js) | AI 서버. **폴더째** 끌어다 놓으면 cloudflare/worker.js 로 올라갑니다 |

## 2. Cloudflare에서 저장소 연결
1. Cloudflare 대시보드 왼쪽 메뉴 **Workers & Pages** (또는 Compute) → **Create** (만들기)
2. **Import a repository** (저장소 가져오기) → **GitHub 연결** → 개인 GitHub(ijinsol61)로 승인
3. `remodel-simulator` 선택 → 설정 화면은 **그대로 두고** **Deploy** (배포)
   - 처음이면 workers.dev 하위 주소 이름을 정하라고 할 수 있습니다. 영문 아무거나 정하면 됩니다.
4. 1~2분 뒤 나오는 주소(`https://remodel-simulator.○○○.workers.dev`)를 엽니다.

이제 GitHub에서 파일을 고치면 Cloudflare 사이트도 자동으로 다시 올라갑니다.

## 3. 잘 됐는지 확인
- 오른쪽 위 표시가 **"AI 연결됨 · Cloudflare FLUX.2 klein"** 으로 바뀌었는지
- 내 방 사진 올리기 → 시나리오·스타일 선택 → **리모델링 이미지 만들기** → 약 10~30초 뒤 After에 결과
- 결과 아래 표기: "AI 생성 이미지 (Cloudflare FLUX.2 klein 이미지 편집, 안전 검사 통과분만 표시)"
- 사람이 나온 사진을 올리면 "사람이 보여 변환하지 않습니다"로 거절되는지

## 4. (선택) 시연 코드 걸기
링크를 아는 누구나 하루 무료 사용량을 쓸 수 있습니다. 막고 싶으면
Worker → **Settings** → **Variables and Secrets** → **Add** → 이름 `ACCESS_CODE`, 종류 Secret, 값은 팀 코드 → Deploy.
화면에 "시연 코드" 칸이 생깁니다.

## 평면도 첨부
스타일 아래 **평면도 (선택)** 에 이 방 평면도를 넣으면 침대·책상·수납·식사 자리를 그 배치대로 그리게 지시합니다.
- 치수를 읽는 것이 아니라 그림으로 참고합니다. 가구를 굵은 사각형으로 표시한 단순한 평면도가 가장 잘 따릅니다.
- 글자가 많은 CAD 도면보다 손그림 사진이나 가구 블록만 있는 캡처가 낫습니다.

## 처리 순서 (안전)
1. 입력 사진 점검: 사람·선정적 내용이 있으면 변환하지 않음
2. 이미지 편집: 원본 사진(+평면도) + 짧은 지시문 → FLUX.2 [klein] 4B
3. Cloudflare 자체 출력 필터
4. 결과 점검: 사람·선정성·로고·글자가 있으면 이미지를 버리고 "차단"만 표시
점검을 못 하면 안전 쪽으로 결과를 표시하지 않습니다.

## 한계 (발표 때 솔직하게)
- 이 모델은 입력 사진을 504px 정도로 줄여서 받습니다. ChatGPT보다 창틀·문틀 같은 세부가 덜 정확하고, 시점이 조금 틀어질 수 있습니다.
- 그래서 **사전 생성 예시(ChatGPT)** 는 대표 결과로, **Cloudflare 실시간 변환** 은 "새 사진도 바로 된다"는 시연용으로 나눠 쓰는 것을 권합니다.

## 문제 해결
| 증상 | 확인 |
|---|---|
| 표시가 "시연용 · AI 연결 전" 그대로 | github.io 주소가 아니라 **workers.dev 주소**로 열었는지 |
| 배포 실패 | 저장소 맨 위에 wrangler.jsonc, cloudflare/worker.js 가 있는지 |
| "Workers AI 연결(AI)이 없습니다" | wrangler.jsonc가 최신인지 |
| 자주 "차단" | 사진에 사람·액자·포스터·글자가 많은지. 정리된 사진으로 다시 |
| 로그 보기 | Worker → Observability(로그)에서 [fail], [blocked] 줄 확인 |
